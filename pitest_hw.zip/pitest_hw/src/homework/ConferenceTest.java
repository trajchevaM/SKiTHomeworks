package homework;

public class ConferenceTest {

    // TODO: Add tests here!
}