package homework;

public enum Course {
    OS,
    EMT,
    SKIT,
    WEB,
    OTHER
}
